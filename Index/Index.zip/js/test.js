// var imgn;
// var srcnew;
// $(document).ready(function () {
    
//         // var x = document.getElementById("tenSp1").textContent;
//         imgn = document.querySelector("#sp1");
//         srcnew = imgn.getAttribute("src");
//         console.log(srcnew);

//         // var image = document.querySelector(".image");
//         // console.log(image);
//         // // var img = "hinh\dior.jpg";
//         // image.setAttribute("src", srcnew);
   
// });